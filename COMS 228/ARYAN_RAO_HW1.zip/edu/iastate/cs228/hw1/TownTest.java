package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.jupiter.api.Test;

/**
 * 
 * @author ARYAN RAO
 *
 */
class TownTest {

	Town town;
	
	@Before
	public void initialize() throws FileNotFoundException
	{
		town = new Town(2, 2);
		town.randomInit(5);
	}

    
    @Test
    public void testLength()
    {
    	town = new Town(2,2);
    	assertEquals(2, town.getLength());
    }
    
    @Test
    public void testWidth()
    {
    	town = new Town(2,2);
    	assertEquals(2, town.getWidth());
    }
    
    @Test
    public void getWidthfromfile() throws FileNotFoundException
    {
    	town = new Town("ISP4X4.txt");
    	assertEquals(4,town.getWidth());
    	
    }

}
