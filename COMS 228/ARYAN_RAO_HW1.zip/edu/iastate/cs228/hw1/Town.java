package edu.iastate.cs228.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


/**
 *  @author ARYAN RAO
 *
 */
public class Town {
	
	private int length, width; 
	public TownCell[][] grid;
	
	/**
	 * Constructor to be used when user wants to generate grid randomly, with the given seed.
	 * This constructor does not populate each cell of the grid (but should assign a 2D array to it).
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		
		this.length = length;
		this.width = width;
		grid = new TownCell[length][width];
	}
	
	
	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of catching it.
	 * Ensure that you close any resources (like file or scanner) which is opened in this function.
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		
		File file = new File(inputFileName);
        Scanner in = new Scanner(file); 
        int length = in.nextInt();
        int width = in.nextInt();
        this.length = length;
        this.width = width;
        grid = new TownCell[length][width];
        in.nextLine();
        
        for (int i = 0; i < length; i++) {
        	
            String[] arr = in.nextLine().split(" ");
            
            for (int j = 0; j < arr.length; j++) {
            	
                
                if(arr[j] =="R")
                {
                    grid[i][j] = new Reseller(this,i,j);
                }
                
                else if(arr[j] =="E")
                {
                    grid[i][j] = new Empty(this,i,j);
                }
                
                else if(arr[j] =="C")
                {
                    grid[i][j] = new Casual(this,i,j);
                }
                    
                else if(arr[j] =="O")
                {
                    grid[i][j] = new Outage(this,i,j);
                }
                
                else if(arr[j] =="S")
                {
                    grid[i][j] = new Streamer(this,i,j);
                }
                
                else if(arr[j] =="R\t")
                {
                    grid[i][j] = new Reseller(this,i,j);
                }
                
                else if(arr[j] =="E\t")
                {
                    grid[i][j] = new Empty(this,i,j);
                }
                
                else if(arr[j] =="C\t")
                {
                    grid[i][j] = new Casual(this,i,j);
                }
                
                else if(arr[j] =="O\t")
                {
                    grid[i][j] = new Outage(this,i,j);
                }
                
                else if(arr[j] =="S\t")
                {
                    grid[i][j] = new Streamer(this,i,j);
                }
               
            }
        }
        in.close();
   
	}
	
	/**
	 * Returns width of the grid.
	 * @return
	 */
	public int getWidth() {
		
		return width;
	}
	
	/**
	 * Returns length of the grid.
	 * @return
	 */
	public int getLength() {
		
		return length;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following class object:
	 * Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		
		Random rand = new Random(seed);
		for (int i = 0; i <= length - 1; i++)
		{
			for (int j = 0; j <= width - 1; j++)
			{
				int temp = rand.nextInt(5);
				
				if (temp == TownCell.RESELLER) 
				{
					grid[i][j] = new Reseller(this, i, j);
				}
				else if (temp == TownCell.EMPTY)
				{

					grid[i][j] = new Empty(this, i, j);
				}
				else if (temp == TownCell.CASUAL) 
				{
					grid[i][j] = new Casual(this, i, j);
				}
				else if (temp == TownCell.OUTAGE) 
				{
					grid[i][j] = new Outage(this, i, j);
				}
				else if (temp == TownCell.STREAMER)
				{
					grid[i][j] = new Streamer(this, i, j);
				}
			}
		}
	}
	
	
	/**
	 * Output the town grid. For each square, output the first letter of the cell type.
	 * Each letter should be separated either by a single space or a tab.
	 * And each row should be in a new line. There should not be any extra line between 
	 * the rows.
	 */
	@Override
	public String toString() {
		
		String str = "";
		for (int i = 0; i <= getLength() - 1; i++) 
		{
			str = str + "\n";
			for (int j = 0; j <= getWidth() - 1; j++) 
			{
				if (grid[i][j].who().equals(State.CASUAL))
				{
					str = str + "C"  + " ";
				}
				else if (grid[i][j].who().equals(State.EMPTY))
				{
					str = str + "E" + " ";
				}
				else if (grid[i][j].who().equals(State.RESELLER))
				{
					str = str + "R" + " ";
				}
				else if (grid[i][j].who().equals(State.OUTAGE))
				{
					str = str + "O" + " ";
				}
				else if (grid[i][j].who().equals(State.STREAMER))
				{
					str = str + "S" + " ";
				}
			}
		}
		return str;
	}
}
