package edu.iastate.cs228.hw1;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author ARYAN RAO
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	
	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		
		Town town = new Town(tOld.getLength(), tOld.getWidth());
		for (int i = 0; i <= tOld.getWidth() - 1; i++) // iterates through the old plain
		{
			for (int j = 0; j <= tOld.getWidth() - 1; j++)
			{
				town.grid[i][j] = tOld.grid[i][j].next(town); 
			}
		}
		return town;
	}
	
	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		
		int profit = 0;
		for (int i = 0; i <= town.getLength() - 1; i++) 
		{
		
			for (int j = 0; j <= town.getWidth() - 1; j++) 
			{
				if(town.grid[i][j].who().equals(State.CASUAL)) {
					profit++;
				}
			}
		}
		return profit;
	}
	

	/**
	 *  Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should print the profit percentage
	 *  with two digits after the decimal point:  Example if profit is 35.5600004, your output
	 *  should be:
	 *
	 *	35.56%
	 *  
	 * Note that this method does not throw any exception, so you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String []args) {
		
		    Scanner scnr = new Scanner(System.in);  
	        System.out.println("PRESS 1 TO INPUT A FILE");
	        System.out.println("PRESS 2 TO GENERATE A GRID");
	        
	        int choice = scnr.nextInt();  
	        int length = 0;
	        int width = 0;
	        int flag = 0;
	        Town town;
	        
	        if (choice == 1) {
	            Scanner file = new Scanner(System.in);
	            System.out.println("ENTER THE NAME OF FILE");
	            String filename = file.nextLine();
	            
	            try {
	                town = new Town(filename);
	            } catch (FileNotFoundException e) {
	                
	                e.printStackTrace();
	                file.close();
	                return;
	            }
	       

	        }
	        else if(choice == 2) {
	            Scanner f2 = new Scanner(System.in);
	            System.out.println("ENTER ROWS, COLUMNS AND SEED INTEGER");
	            length = f2.nextInt();
	            width = f2.nextInt();
	            flag = f2.nextInt();
	            town = new Town(length, width);
	            town.randomInit(flag);
	            f2.close();
	        }
	        else {
	            System.out.println("INVALID");
	            return;
	        }
	        
	       
	        int profit = 0;
	        for(int i = 1; i <= 12; i++) {
	            
	            System.out.print(town.toString());
	            System.out.print("\n");

	           
	        profit = getProfit(town);
	        System.out.println("PROFIT: " + profit); 
	        town =  updatePlain(town);
	        }
	   		int potential = town.getLength() * town.getWidth();
	  		double percent = (profit * 100) / potential;
	        System.out.println("PROFIT %: " + percent); 
		}
		
	
	}

